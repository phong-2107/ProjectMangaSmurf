using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectMangaSmurf.Views.CustomPages
{
    public class HeaderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
