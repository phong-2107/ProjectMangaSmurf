﻿using System;
using System.Collections.Generic;

namespace ProjectMangaSmurf.Models;

public class Premium
{
    public decimal? GiaThanh { get; set; }

    public bool? Active { get; set; }
}
