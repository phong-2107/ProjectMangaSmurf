﻿using System;
using System.Collections.Generic;

namespace ProjectMangaSmurf.Models;

public class Footer
{
    public string? LinkFb { get; set; }

    public string? LinkIns { get; set; }

    public string? LinkX { get; set; }

    public string? LinkDiscord { get; set; }

    public string? Noidung { get; set; }

    public string? Dieukhoan { get; set; }

    public string? Note { get; set; }

    public string? Giayphep { get; set; }
}
